package com.example.studyrestful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyrestfulApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudyrestfulApplication.class, args);
	}

}
